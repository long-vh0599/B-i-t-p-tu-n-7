package vn.edu.hust.example_gmail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import io.bloco.faker.Faker;
import vn.edu.hust.example_gmail.adapter.ItemAdapter;
import vn.edu.hust.example_gmail.model.ItemModel;

public class MainActivity extends AppCompatActivity {

    List<ItemModel> items;
    ItemAdapter adapter;
    boolean isShowingFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Faker faker = new Faker();

        items = new ArrayList<>();
        for (int i = 0; i < 20; i++)
            items.add(new ItemModel(faker.name.name(), faker.lorem.sentence(), faker.lorem.paragraph(), "12:00 PM"));

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ItemAdapter(items);
        recyclerView.setAdapter(adapter);
        isShowingFavorite = false;

        findViewById(R.id.btn_favorite).requestFocus();
        findViewById(R.id.btn_favorite).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isShowingFavorite = !isShowingFavorite;

                if (isShowingFavorite)
                    adapter.showFavorites();
                else
                    adapter.showFavorites();
            }
        });

        final EditText editKeyword = findViewById(R.id.edit_keyword);
        editKeyword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String keyword = editable.toString();
                if (keyword.length() > 2)
                    adapter.search(keyword);
                else
                    adapter.showAll();
            }
        });
    }
}
