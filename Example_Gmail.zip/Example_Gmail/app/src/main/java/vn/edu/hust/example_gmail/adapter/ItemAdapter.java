package vn.edu.hust.example_gmail.adapter;

import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;

import vn.edu.hust.example_gmail.R;
import vn.edu.hust.example_gmail.model.ItemModel;

public class ItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    List<ItemModel> allItems;
    List<ItemModel> dispalyItems;
    String keyword;
    boolean isShowingFavorite;

    public ItemAdapter(List<ItemModel> items) {
        this.allItems = items;

        dispalyItems = new ArrayList<>();
        dispalyItems.addAll(allItems);
        keyword = "";
        isShowingFavorite = false;
    }

    public void showAll() {
        dispalyItems.clear();
        dispalyItems.addAll(allItems);
        isShowingFavorite = false;
        notifyDataSetChanged();
    }

    public void search(String keyword) {
        this.keyword = keyword;
        dispalyItems.clear();
        for(ItemModel item : allItems) {
            if (item.getName().contains(keyword) || item.getSubject().contains(keyword) || item.getContent().contains(keyword))
                dispalyItems.add(item);
        }
        isShowingFavorite = false;
        notifyDataSetChanged();
    }

    public void showFavorites() {
        this.keyword = "";
        dispalyItems.clear();
        for(ItemModel item : allItems) {
            if (item.isFavorite())
                dispalyItems.add(item);
        }
        isShowingFavorite = true;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item, parent, false);
        return new EmailViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        EmailViewHolder viewHolder = (EmailViewHolder) holder;
        ItemModel item = dispalyItems.get(position);

        viewHolder.textLetter.setText(item.getName().substring(0, 1));
        Drawable background = viewHolder.textLetter.getBackground();
        background.setColorFilter(new PorterDuffColorFilter(item.getColor(), PorterDuff.Mode.SRC_ATOP));

        if (keyword.length() > 2) {
            String name = item.getName().replace(keyword, "<b>" + keyword + "</b>");
            String subject = item.getSubject().replace(keyword, "<b>" + keyword + "</b>");
            String content = item.getContent().replace(keyword, "<b>" + keyword + "</b>");

            viewHolder.textName.setText(Html.fromHtml(name));
            viewHolder.textSubject.setText(Html.fromHtml(subject));
            viewHolder.textContent.setText(Html.fromHtml(content));
        } else {
            viewHolder.textName.setText(item.getName());
            viewHolder.textSubject.setText(item.getSubject());
            viewHolder.textContent.setText(item.getContent());
        }

        viewHolder.textTime.setText(item.getTime());
        if (item.isFavorite())
            viewHolder.imageFavorite.setImageResource(R.drawable.ic_star_favorite);
        else
            viewHolder.imageFavorite.setImageResource(R.drawable.ic_star_normal);
    }

    @Override
    public int getItemCount() {
        return dispalyItems.size();
    }

    class EmailViewHolder extends RecyclerView.ViewHolder {
        TextView textLetter;
        TextView textName;
        TextView textSubject;
        TextView textContent;
        TextView textTime;
        ImageView imageFavorite;


        public EmailViewHolder(@NonNull View itemView) {
            super(itemView);

            textLetter = itemView.findViewById(R.id.text_letter);
            textName = itemView.findViewById(R.id.text_name);
            textSubject = itemView.findViewById(R.id.text_subject);
            textContent = itemView.findViewById(R.id.text_content);
            textTime = itemView.findViewById(R.id.text_time);
            imageFavorite = itemView.findViewById(R.id.image_favorite);

            imageFavorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean isFavorite = dispalyItems.get(getAdapterPosition()).isFavorite();
                    dispalyItems.get(getAdapterPosition()).setFavorite(!isFavorite);

                    if (isShowingFavorite)
                        dispalyItems.remove(getAdapterPosition());

                    notifyDataSetChanged();
                }
            });
        }
    }
}